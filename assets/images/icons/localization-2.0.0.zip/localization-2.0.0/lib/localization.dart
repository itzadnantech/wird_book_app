library localization;

export 'src/localization_extension.dart';
export 'src/delegates/local_json_localization.dart';
