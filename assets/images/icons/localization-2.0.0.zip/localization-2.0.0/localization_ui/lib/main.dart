import 'package:flutter/material.dart';

import 'src/app_widget.dart';

void main() {
  runApp(MyApp());
}
